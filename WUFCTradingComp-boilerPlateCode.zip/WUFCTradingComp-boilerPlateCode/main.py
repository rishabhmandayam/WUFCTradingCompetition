# exchange/main.py

import tkinter as tk
from tkinter import ttk, messagebox
import time
from Order import Order
from OrderBookManager import OrderBookManager
from Participant import Participant
from ParticipantManager import ParticipantManager
from app import order_book_manager
from liquidityBot import LiquidityBot
from PriceGenerator import PriceGenerator
import threading


class TradingExchangeGUI:
    def __init__(self, root):
        self.root = root
        self.participant_manager = ParticipantManager()
        self.order_book_manager = OrderBookManager(self.participant_manager)
        self.root.title("Simulated Trading Exchange")
        self.root.geometry("1600x900")  # Increased size for better layout
        self.price_generator = PriceGenerator(seed=42)
        self.initialize_securities()
        self.price_generator.start()
        self.initialize_liquidity_bots(num_bots=1)  # Initialize 100 bots
        self.create_widgets()
        self.update_order_book_display()

    def initialize_securities(self):
        """
        Adds initial securities to the PriceGenerator and initializes their order books.
        """
        # Example securities
        securities = [
            {"symbol": "AAPL", "initial_price": 150.0, "drift": 0.0001, "volatility": 0.01, "time_step": 1.0},
            {"symbol": "GOOGL", "initial_price": 175.0, "drift": 0.00005, "volatility": 0.015, "time_step": 1.0},
            {"symbol": "AMZN", "initial_price": 200.0, "drift": 0.00007, "volatility": 0.012, "time_step": 1.0},
            # Add more securities as needed
        ]

        for sec in securities:
            self.price_generator.add_security(
                symbol=sec["symbol"],
                initial_price=sec["initial_price"],
                drift=sec["drift"],
                volatility=sec["volatility"],
                time_step=sec["time_step"]
            )
            self.order_book_manager.add_order_book(sec["symbol"])  # Initialize order books

    def initialize_liquidity_bots(self, num_bots: int):
        """
        Initializes and starts multiple LiquidityBot instances.

        :param num_bots: Number of LiquidityBots to initialize.
        """
        for i in range(1, num_bots + 1):
            participant_id = f"LiquidityBot_{i}"
            bot = LiquidityBot(
                participant_id=participant_id,
                order_book_manager=self.order_book_manager,
                price_generator=self.price_generator)
            self.participant_manager.add_participant(bot)
            bot.start()
            time.sleep(0.01)  # Small delay to prevent thread thrashing


    def create_widgets(self):
        # Create Frames
        self.order_frame = ttk.LabelFrame(self.root, text="Place Order")
        self.order_frame.pack(fill="x", padx=10, pady=5)

        self.order_book_frame = ttk.LabelFrame(self.root, text="Order Book")
        self.order_book_frame.pack(fill="both", expand=True, padx=10, pady=5)

        self.trades_frame = ttk.LabelFrame(self.root, text="Executed Trades")
        self.trades_frame.pack(fill="both", expand=True, padx=10, pady=5)

        self.portfolio_frame = ttk.LabelFrame(self.root, text="Participant Portfolio")
        self.portfolio_frame.pack(fill="both", expand=True, padx=10, pady=5)

        # Place Order Frame Widgets
        # Side
        ttk.Label(self.order_frame, text="Side:").grid(row=0, column=0, padx=5, pady=5, sticky="e")
        self.side_var = tk.StringVar(value="buy")
        ttk.Radiobutton(self.order_frame, text="Buy", variable=self.side_var, value="buy").grid(row=0, column=1, padx=5,
                                                                                                pady=5)
        ttk.Radiobutton(self.order_frame, text="Sell", variable=self.side_var, value="sell").grid(row=0, column=2,
                                                                                                  padx=5, pady=5)

        # Order Type
        ttk.Label(self.order_frame, text="Order Type:").grid(row=0, column=3, padx=5, pady=5, sticky="e")
        self.order_type_var = tk.StringVar(value="limit")
        ttk.Radiobutton(self.order_frame, text="Limit", variable=self.order_type_var, value="limit",
                        command=self.toggle_price_entry).grid(row=0, column=4, padx=5, pady=5)
        ttk.Radiobutton(self.order_frame, text="Market", variable=self.order_type_var, value="market",
                        command=self.toggle_price_entry).grid(row=0, column=5, padx=5, pady=5)

        # Price
        ttk.Label(self.order_frame, text="Price:").grid(row=1, column=0, padx=5, pady=5, sticky="e")
        self.price_entry = ttk.Entry(self.order_frame)
        self.price_entry.grid(row=1, column=1, padx=5, pady=5, sticky="w")

        # Quantity
        ttk.Label(self.order_frame, text="Quantity:").grid(row=1, column=2, padx=5, pady=5, sticky="e")
        self.quantity_entry = ttk.Entry(self.order_frame)
        self.quantity_entry.grid(row=1, column=3, padx=5, pady=5, sticky="w")

        # Participant ID
        ttk.Label(self.order_frame, text="Participant ID:").grid(row=1, column=4, padx=5, pady=5, sticky="e")
        self.participant_entry = ttk.Entry(self.order_frame)
        self.participant_entry.grid(row=1, column=5, padx=5, pady=5, sticky="w")

        # Ticker Selection
        ttk.Label(self.order_frame, text="Ticker:").grid(row=2, column=0, padx=5, pady=5, sticky="e")
        self.ticker_var = tk.StringVar()
        self.ticker_combobox = ttk.Combobox(self.order_frame, textvariable=self.ticker_var, state="readonly")
        self.ticker_combobox['values'] = list(self.price_generator.securities.keys())
        if self.ticker_combobox['values']:
            self.ticker_combobox.current(0)  # Select the first ticker by default
        self.ticker_combobox.grid(row=2, column=1, padx=5, pady=5, sticky="w")

        # Bind the ticker selection to update the order book display
        self.ticker_combobox.bind("<<ComboboxSelected>>", self.update_order_book_display)

        # Submit Button Adjustment
        self.submit_button = ttk.Button(self.order_frame, text="Submit Order", command=self.submit_order)
        self.submit_button.grid(row=2, column=2, columnspan=4, pady=10)

        # Order Book Frame Widgets
        # Bids Treeview
        ttk.Label(self.order_book_frame, text="Bids").grid(row=0, column=0, padx=5, pady=5)
        self.bids_tree = ttk.Treeview(self.order_book_frame, columns=("Price", "Quantity", "Timestamp"),
                                      show="headings")
        self.bids_tree.heading("Price", text="Price")
        self.bids_tree.heading("Quantity", text="Quantity")
        self.bids_tree.heading("Timestamp", text="Timestamp")
        self.bids_tree.column("Price", width=100, anchor="center")
        self.bids_tree.column("Quantity", width=100, anchor="center")
        self.bids_tree.column("Timestamp", width=200, anchor="center")
        self.bids_tree.grid(row=1, column=0, padx=5, pady=5, sticky="nsew")

        # Asks Treeview
        ttk.Label(self.order_book_frame, text="Asks").grid(row=0, column=1, padx=5, pady=5)
        self.asks_tree = ttk.Treeview(self.order_book_frame, columns=("Price", "Quantity", "Timestamp"),
                                      show="headings")
        self.asks_tree.heading("Price", text="Price")
        self.asks_tree.heading("Quantity", text="Quantity")
        self.asks_tree.heading("Timestamp", text="Timestamp")
        self.asks_tree.column("Price", width=100, anchor="center")
        self.asks_tree.column("Quantity", width=100, anchor="center")
        self.asks_tree.column("Timestamp", width=200, anchor="center")
        self.asks_tree.grid(row=1, column=1, padx=5, pady=5, sticky="nsew")

        # Configure grid weights
        self.order_book_frame.columnconfigure(0, weight=1)
        self.order_book_frame.columnconfigure(1, weight=1)
        self.order_book_frame.rowconfigure(1, weight=1)

        # Trades Frame Widgets
        self.trades_tree = ttk.Treeview(self.trades_frame, columns=(
        "Symbol", "Buy Order ID", "Sell Order ID", "Price", "Quantity", "Timestamp"), show="headings")
        self.trades_tree.heading("Symbol", text="Symbol")
        self.trades_tree.heading("Buy Order ID", text="Buy Order ID")
        self.trades_tree.heading("Sell Order ID", text="Sell Order ID")
        self.trades_tree.heading("Price", text="Price")
        self.trades_tree.heading("Quantity", text="Quantity")
        self.trades_tree.heading("Timestamp", text="Timestamp")
        self.trades_tree.column("Symbol", width=80, anchor="center")
        self.trades_tree.column("Buy Order ID", width=150, anchor="center")
        self.trades_tree.column("Sell Order ID", width=150, anchor="center")
        self.trades_tree.column("Price", width=100, anchor="center")
        self.trades_tree.column("Quantity", width=100, anchor="center")
        self.trades_tree.column("Timestamp", width=200, anchor="center")
        self.trades_tree.pack(fill="both", expand=True, padx=5, pady=5)

        # Participant Portfolio Frame
        self.portfolio_frame = ttk.LabelFrame(self.root, text="Participant Portfolio")
        self.portfolio_frame.pack(fill="both", expand=True, padx=10, pady=5)

        self.portfolio_tree = ttk.Treeview(self.portfolio_frame,
                                           columns=("Participant ID", "Symbol", "Holdings", "Balance"), show="headings")
        self.portfolio_tree.heading("Participant ID", text="Participant ID")
        self.portfolio_tree.heading("Symbol", text="Symbol")
        self.portfolio_tree.heading("Holdings", text="Holdings")
        self.portfolio_tree.heading("Balance", text="Balance")
        self.portfolio_tree.column("Participant ID", width=150, anchor="center")
        self.portfolio_tree.column("Symbol", width=80, anchor="center")
        self.portfolio_tree.column("Holdings", width=100, anchor="center")
        self.portfolio_tree.column("Balance", width=100, anchor="center")
        self.portfolio_tree.pack(fill="both", expand=True, padx=5, pady=5)

        # Start a thread to periodically update the portfolio display
        self.portfolio_update_thread = threading.Thread(target=self.update_portfolio_display, daemon=True)
        self.portfolio_update_thread.start()

        # Start a thread to periodically update the order book display
        self.update_thread = threading.Thread(target=self.periodic_update, daemon=True)
        self.update_thread.start()

    def toggle_price_entry(self):
        """
        Enables or disables the price entry based on the order type.
        Market orders do not require a price.
        """
        if self.order_type_var.get() == "market":
            self.price_entry.configure(state="disabled")
            self.price_entry.delete(0, tk.END)
        else:
            self.price_entry.configure(state="normal")

    def submit_order(self):
        """
        Collects order details from the form and submits the order.
        """
        side = self.side_var.get()
        order_type = self.order_type_var.get()
        participant_id = self.participant_entry.get().strip()
        quantity = self.quantity_entry.get().strip()
        price = self.price_entry.get().strip()
        symbol = self.ticker_var.get()

        # Validate inputs
        if not participant_id:
            messagebox.showerror("Input Error", "Participant ID is required.")
            return

        if not quantity.isdigit() or int(quantity) <= 0:
            messagebox.showerror("Input Error", "Quantity must be a positive integer.")
            return

        if not symbol:
            messagebox.showerror("Input Error", "Ticker symbol is required.")
            return

        quantity = int(quantity)

        if order_type == "limit":
            try:
                price = float(price)
                if price <= 0:
                    raise ValueError
            except ValueError:
                messagebox.showerror("Input Error", "Price must be a positive number for limit orders.")
                return
            order = Order.create_limit_order(price=price, quantity=quantity, side=side, participant_id=participant_id,
                                             symbol=symbol)
        else:  # Market order
            order = Order.create_market_order(quantity=quantity, side=side, participant_id=participant_id,
                                              symbol=symbol)

        # Create or retrieve Participant instance
        participant = self.participant_manager.get_participant(participant_id)
        if not participant:
            participant = Participant(participant_id=participant_id)
            self.participant_manager.add_participant(participant)

        # Add order to the order book manager
        if participant.place_order(self.order_book_manager, order):
            self.update_order_book_display()



        # Clear input fields
        self.clear_order_form()

    def clear_order_form(self):
        """
        Clears the order input fields.
        """
        self.price_entry.delete(0, tk.END)
        self.quantity_entry.delete(0, tk.END)
        self.participant_entry.delete(0, tk.END)

    def update_order_book_display(self, event=None):
        """
        Updates the order book display in the GUI based on the selected ticker.
        """
        selected_symbol = self.ticker_var.get()
        order_book = self.order_book_manager.get_order_book_snapshot(selected_symbol)

        # Schedule GUI updates in the main thread
        def clear_and_insert():
            # Clear existing data
            for item in self.bids_tree.get_children():
                self.bids_tree.delete(item)
            for item in self.asks_tree.get_children():
                self.asks_tree.delete(item)

            # Insert new data
            for bid in order_book['bids']:
                price, quantity, timestamp = bid
                time_str = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(timestamp))
                self.bids_tree.insert("", tk.END, values=(f"${price:.2f}", quantity, time_str))

            for ask in order_book['asks']:
                price, quantity, timestamp = ask
                time_str = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(timestamp))
                self.asks_tree.insert("", tk.END, values=(f"${price:.2f}", quantity, time_str))

        self.root.after(0, clear_and_insert)

    def process_trades(self, trades):
        """
        Processes executed trades and updates the trade history display.
        """
        for trade in trades:
            buy_order, sell_order, price, quantity = trade
            symbol = buy_order.symbol  # Assuming both orders have the same symbol
            timestamp = time.time()
            time_str = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(timestamp))

            # Schedule GUI update in the main thread
            self.root.after(0, self.trades_tree.insert, "", tk.END, values=(
                symbol,
                buy_order.order_id[:8],  # Display first 8 chars for brevity
                sell_order.order_id[:8],
                f"${price:.2f}" if isinstance(price, float) else "Market Price",
                quantity,
                time_str
            ))

    def update_portfolio_display(self):
        """
        Periodically updates the participant portfolio display.
        """
        while True:
            participants = self.participant_manager.get_all_participants()
            # Prepare data to update
            portfolio_data = []
            for participant in participants.values():
                for symbol, holdings in participant.__portfolio.items():
                    portfolio_data.append((
                        participant.participant_id,
                        symbol,
                        holdings,
                        f"${participant.__balance:.2f}"
                    ))

            # Schedule GUI update in the main thread
            self.root.after(0, self.refresh_portfolio_tree, portfolio_data)
            time.sleep(5)  # Update every 5 seconds

    def refresh_portfolio_tree(self, portfolio_data):
        """
        Refreshes the participant portfolio Treeview with new data.

        :param portfolio_data: List of tuples containing portfolio information.
        """
        self.portfolio_tree.delete(*self.portfolio_tree.get_children())
        for data in portfolio_data:
            self.portfolio_tree.insert("", tk.END, values=data)

    def periodic_update(self):
        """
        Periodically updates the order book display to reflect real-time price changes.
        """
        while True:
            self.update_order_book_display()
            time.sleep(1)  # Update every second

    def run(self):
        """
        Starts the GUI main loop.
        """
        self.root.protocol("WM_DELETE_WINDOW", self.on_closing)
        self.root.mainloop()

    def on_closing(self):
        """
        Handles the GUI window closing event.
        Ensures that the LiquidityBot and PriceGenerator are stopped gracefully.
        """
        if messagebox.askokcancel("Quit", "Do you want to quit?"):
            # Stop all LiquidityBots
            for participant in self.participant_manager.get_all_participants().values():
                if isinstance(participant, LiquidityBot):
                    participant.stop()
            self.price_generator.stop()
            self.root.destroy()


def main():
    root = tk.Tk()
    app = TradingExchangeGUI(root)
    app.run()



if __name__ == "__main__":
    main()
