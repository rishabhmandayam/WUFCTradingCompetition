# competitor.py

import time
import logging
from typing import Optional, List, Dict

# Import the Participant class from your exchange package
from Participant import Participant

class Competitor(Participant):
    def __init__(self, 
                 participant_id: str,
                 order_book_manager=None,
                 order_queue_manager=None,
                 balance: float = 100000.0):
        """
        Initializes the Competitor with default strategy parameters.
        
        :param participant_id: Unique ID for the competitor.
        :param order_book_manager: Reference to the OrderBookManager.
        :param order_queue_manager: Reference to the OrderQueueManager.
        :param balance: Starting balance for the competitor.
        """
        # Initialize the base Participant class
        super().__init__(
            participant_id=participant_id,
            balance=balance,
            order_book_manager=order_book_manager,
            order_queue_manager=order_queue_manager
        )

        # Strategy parameters (fixed defaults)
        self.symbols: List[str] = ["NVR", "CPMD", "ANG", "MFH", "TVW"]
        self.max_position: int = 100
        self.max_balance_use_fraction: float = 0.2
        self.max_order_age: float = 30.0
        self.stale_check_interval: float = 15.0

        # Track (order_id, timestamp) for each symbol to manage stale orders
        self.active_orders: Dict[str, List] = {sym: [] for sym in self.symbols}
        self.last_stale_check: float = 0.0  # Time of last stale-check

    def strategy(self):
        """
        Main market-making strategy that:
          1. Cancels stale orders if enough time has passed.
          2. For each symbol, retrieves best bid/ask and places buy/sell limit orders 
             around the midpoint, adjusted by position and balance constraints.
        """
        current_time = time.time()

        # 1. Possibly cancel stale orders if enough time has passed
        if current_time - self.last_stale_check >= self.stale_check_interval:
            self.cancel_stale_orders()
            self.last_stale_check = current_time

        # 2. For each symbol, execute market-making logic
        for symbol in self.symbols:
            self.place_market_making_orders_for_symbol(symbol)

    def place_market_making_orders_for_symbol(self, symbol: str):
        """
        Executes market-making logic for a single symbol.
        
        Steps:
          1. Retrieve the best bid and ask from the order book.
          2. Calculate prices slightly inside the midpoint.
          3. Adjust order quantities based on current holdings and balance.
          4. Place buy and sell limit orders if feasible.
        """
        snapshot = self.get_order_book_snapshot(symbol)
        bids = snapshot.get('bids', [])
        asks = snapshot.get('asks', [])

        if not bids or not asks:
            #loggingdebug(f"[{self.participant_id}] No bids or asks available for {symbol}. Skipping.")
            return  # Not enough market data

        best_bid = bids[0][0]  # Highest bid price
        best_ask = asks[0][0]  # Lowest ask price

        if not best_bid or not best_ask or best_bid <= 0 or best_ask <= 0:
            #loggingdebug(f"[{self.participant_id}] Invalid best bid/ask for {symbol}. Skipping.")
            return

        spread = best_ask - best_bid
        if spread <= 0:
            #loggingdebug(f"[{self.participant_id}] Spread <= 0 for {symbol}. Skipping.")
            return  # Invalid market

        # Calculate buy and sell prices slightly inside the midpoint
        half_spread = spread / 2
        buy_price = best_bid + half_spread * 0.8
        sell_price = best_ask - half_spread * 0.8

        # Current holdings
        current_position = self.get_portfolio.get(symbol, 0)

        # Desired quantity for each order
        desired_quantity = 10

        # Adjust buy and sell quantities based on position and balance
        buy_quantity = self.adaptive_quantity_for_buy(current_position, desired_quantity)
        buy_quantity = self.enforce_balance_check(buy_price, buy_quantity)

        sell_quantity = self.adaptive_quantity_for_sell(current_position, desired_quantity)

        placed_any = False

        # Place BUY limit order
        if buy_quantity > 0:
            buy_order_id = self.create_limit_order(
                price=buy_price,
                size=buy_quantity,
                side='buy',
                symbol=symbol
            )
            if buy_order_id:
                self.track_order(symbol, buy_order_id)
                #logginginfo(f"[{self.participant_id}] Placed BUY order {buy_order_id} for {symbol} at {buy_price}")
                placed_any = True

        # Place SELL limit order
        if sell_quantity > 0:
            sell_order_id = self.create_limit_order(
                price=sell_price,
                size=sell_quantity,
                side='sell',
                symbol=symbol
            )
            if sell_order_id:
                self.track_order(symbol, sell_order_id)
                #logginginfo(f"[{self.participant_id}] Placed SELL order {sell_order_id} for {symbol} at {sell_price}")
                placed_any = True

        if not placed_any:
            #loggingdebug(f"[{self.participant_id}] No orders placed for {symbol} this cycle.")
            pass

    def cancel_stale_orders(self):
        """
        Cancels orders that have exceeded the maximum allowed age.
        """
        current_time = time.time()
        for symbol, orders_list in self.active_orders.items():
            still_active = []
            for (order_id, timestamp) in orders_list:
                age = current_time - timestamp
                if age > self.max_order_age:
                    # Use Participant's remove_order to cancel the order
                    success = self.remove_order(order_id, symbol)
                else:
                    # Keep it in the active list if not stale
                    still_active.append((order_id, timestamp))
            self.active_orders[symbol] = still_active

    def adaptive_quantity_for_buy(self, current_position: int, desired_quantity: int) -> int:
        """
        Adjusts buy quantity based on current position and maximum allowed position.
        """
        if current_position >= self.max_position:
            return 0
        elif current_position > 0:
            portion_left = self.max_position - current_position
            scale_factor = portion_left / float(self.max_position)
            return max(1, int(desired_quantity * scale_factor))
        else:
            return desired_quantity

    def adaptive_quantity_for_sell(self, current_position: int, desired_quantity: int) -> int:
        """
        Adjusts sell quantity based on current position and maximum allowed short position.
        """
        if current_position <= -self.max_position:
            return 0
        elif current_position < 0:
            portion_left = self.max_position - abs(current_position)
            scale_factor = portion_left / float(self.max_position)
            return max(1, int(desired_quantity * scale_factor))
        else:
            return desired_quantity

    def enforce_balance_check(self, buy_price: float, buy_quantity: int) -> int:
        """
        Ensures that the buy order does not exceed the allowed balance fraction.
        """
        if buy_quantity <= 0:
            return 0
        max_cost_estimate = buy_price * buy_quantity
        allowed_cost = self.get_balance * self.max_balance_use_fraction
        if max_cost_estimate > allowed_cost:
            new_q = int(allowed_cost // buy_price)
            return max(0, min(new_q, buy_quantity))
        return buy_quantity

    def track_order(self, symbol: str, order_id: str):
        """
        Tracks the order by storing its ID and timestamp.
        """
        self.active_orders.setdefault(symbol, []).append((order_id, time.time()))
