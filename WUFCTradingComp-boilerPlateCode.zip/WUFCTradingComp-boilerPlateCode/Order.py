# exchange/order.py

import time
import uuid
from enum import Enum
from dataclasses import dataclass, field
from typing import Optional
from functools import total_ordering

class orderLife(Enum):
    CREATED = "CREATED"
    INORDERBOOK = "INORDERBOOK"
    PARTIALLY_FILLED = "PARTIALLY_FILLED"
    FILLED = "FILLED"
    CANCELLED = "CANCELLED"


@dataclass
@total_ordering
class Order:
    sort_index: tuple = field(init=False, repr=False)
    order_id: str
    timestamp: float
    price: Optional[float]  # None for market orders
    quantity: int
    side: str  # 'buy' or 'sell' ## or 'cancel' ???
    order_type: str  # 'market' or 'limit'
    participant_id: str
    symbol: str  # Ticker symbol of the security

    orderLife = orderLife.CREATED


    def __post_init__(self):
        """
        Define sort_index based on order type and side to ensure proper priority in the heap.
        For buy orders:
            - Market orders have higher priority than limit orders.
            - Among limit orders, higher price has higher priority.
        For sell orders:
            - Market orders have higher priority than limit orders.
            - Among limit orders, lower price has higher priority.
        """
        if self.side not in {'buy', 'sell'}:
            raise ValueError("Order side must be 'buy' or 'sell'.")
        if self.order_type not in {'market', 'limit'}:
            raise ValueError("Order type must be 'market' or 'limit'.")

        if self.side == 'buy':
            # For BUY: Market orders get top priority with price_priority = -∞
            # For limit orders, higher price has higher priority => negative
            if self.order_type == 'market':
                price_priority = float('-inf')
            else:
                price_priority = -self.price
        else:  # self.side == 'sell'
            # For SELL: Market orders get top priority with price_priority = +∞
            # For limit orders, lower price has higher priority => just self.price
            if self.order_type == 'market':
                price_priority = float('inf')
            else:
                price_priority = self.price

        # Sort index: (order_type_priority, price_priority, timestamp)
        # where market < limit => 0 < 1
        self.sort_index = (
            0 if self.order_type == 'market' else 1,  # Market first
            price_priority,
            self.timestamp
        )

    def __lt__(self, other: 'Order') -> bool:
        if not isinstance(other, Order):
            return NotImplemented
        return self.sort_index < other.sort_index

    def __eq__(self, other: 'Order') -> bool:
        if not isinstance(other, Order):
            return NotImplemented
        return self.sort_index == other.sort_index

    @staticmethod
    def create_limit_order(price: float, quantity: int, side: str, participant_id: str, symbol: str) -> 'Order':
        """
        Factory method to create a limit order.
        """
        if price <= 0:
            raise ValueError("Limit order price must be positive.")
        return Order(
            order_id=str(uuid.uuid4()),
            timestamp=time.time(),
            price=price,
            quantity=quantity,
            side=side,
            order_type='limit',
            participant_id=participant_id,
            symbol=symbol
        )

    @staticmethod
    def create_market_order(quantity: int, side: str, participant_id: str, symbol: str) -> 'Order':
        """
        Factory method to create a market order.
        """
        return Order(
            order_id=str(uuid.uuid4()),
            timestamp=time.time(),
            price=None,  # Market orders do not have a price
            quantity=quantity,
            side=side,
            order_type='market',
            participant_id=participant_id,
            symbol=symbol
        )
